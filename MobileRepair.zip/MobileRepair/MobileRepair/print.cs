﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MobileRepair
{
    public partial class print : Form
    {
        public print()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection("server=YOTA; database=repairshop; user=sa; password=12345");

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void print_Load(object sender, EventArgs e)
        {
            label10.Text = repairid;
            getId(repairid);

        }

        private string repairid;

        public string RepairId
        {
            get { return repairid; }
            set { repairid = value; }
        }

        private void getId(String repairid)
        {
            string sql;

            sql = "select * from records where repairid = '" + repairid + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dread;
            con.Open();
            dread = cmd.ExecuteReader();

            while(dread.Read())
            {
                label10.Text = dread[2].ToString();
                label11.Text = dread[3].ToString();
                label12.Text = dread[4].ToString();

                label13.Text = dread[10].ToString();
                label14.Text = dread[11].ToString();
                label15.Text = dread[12].ToString();
                label16.Text = dread[13].ToString();
            }

            con.Close();
        }




    }
}
