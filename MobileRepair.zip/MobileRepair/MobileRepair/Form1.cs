﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MobileRepair
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        SqlConnection con = new SqlConnection("server=YOTA; database=repairshop; user=sa; password=12345");

        private void autoId()
        {
            string repid, itemid;

            string sql = "select repairid from records order by repairid desc";
            con.Open();

            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();

            if(dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                itemid = id.ToString("00000");
            }
            else if(Convert.IsDBNull(dr))
            {
                itemid = ("00001");
            }
            else
            {
                itemid = ("00001");
            }
            txtrepairid.Text = itemid.ToString();

            con.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            autoId();
            txtcustname.Focus();
            this.ActiveControl = txtcustname;
        }

        private void txtrepairp_TextChanged(object sender, EventArgs e)
        {
            txtsub.Text = txtrepairp.Text;
        }

        private void txtpay_TextChanged(object sender, EventArgs e)
        {
            int tot;
            int subtotal = int.Parse(txtsub.Text);
            int pay = int.Parse(txtpay.Text);

            tot = subtotal - pay;

            txtbal.Text = tot.ToString();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "insert into records(repairid,custname,phoneno,model,sn,pattern,status,conpower,conwater,conph,repairprice,subtotal,paid,balance,assign,date)values(@repairid,@custname,@phoneno,@model,@sn,@pattern,@status,@conpower,@conwater,@conph,@repairprice,@subtotal,@paid,@balance,@assign,@date)";
                cmd.Parameters.AddWithValue("@repairid", txtrepairid.Text);
                cmd.Parameters.AddWithValue("@custname", txtcustname.Text);
                cmd.Parameters.AddWithValue("@phoneno", txtphone.Text);
                cmd.Parameters.AddWithValue("@model", txtmodel.Text);
                cmd.Parameters.AddWithValue("@sn", txtsn.Text);
                cmd.Parameters.AddWithValue("@pattern", txtpattern.Text);
                cmd.Parameters.AddWithValue("@status", txtstatus.Text);
                cmd.Parameters.AddWithValue("@conpower", checkBox1.Checked);
                cmd.Parameters.AddWithValue("@conwater", checkBox2.Checked);
                cmd.Parameters.AddWithValue("@conph", checkBox3.Checked);
                cmd.Parameters.AddWithValue("@repairprice", txtrepairp.Text);
                cmd.Parameters.AddWithValue("@subtotal", txtsub.Text);
                cmd.Parameters.AddWithValue("@paid", txtpay.Text);
                cmd.Parameters.AddWithValue("@balance", txtbal.Text);

                cmd.Parameters.AddWithValue("@assign", txtassign.Text);
                cmd.Parameters.AddWithValue("@date", txtdate.Value);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record added");

                print pr = new print();
                pr.RepairId = txtrepairid.Text;
                pr.Show();


                con.Close();
                txtcustname.Focus();
                autoId();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
    }
}
